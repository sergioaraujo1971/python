from distutils.core import setup
setup(
    name='lista',
    version='1.0.0',
    py_modules=['listas'],
    author='Sergio A Araujo',
    author_email='saaraujo@msn.com',
    url='https://github.com/sergioaraujo1971',
    description='programa de execução de listas de filmes favoritos'
)
